﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain.Models
{
    public partial class ScholarShipApplication : AuditEntity
    {
        public ScholarShipApplication()
        {

        }

        public int IndividualID { get; set; }
        public int ScholarShipID { get; set; }
        public Boolean IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? Approvedon { get; set; }
        public virtual ScholarShip ScholarShip { get; set; }
        public virtual Individual Individual { get; set; }
    }
}
