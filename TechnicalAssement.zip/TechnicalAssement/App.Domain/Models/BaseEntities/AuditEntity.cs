﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace App.Domain.Models
{
    public class AuditEntity
    {
        public int ID { get; set; }
        [DefaultValue(false)]
        public bool IsDeleted { get; set; } = false;
        public string DeletedUser { get; set; }
        public DateTime? AddedDate { get; set; }
        public string AddedUser { get; set; }
        public DateTime? Deleteddate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedUser { get; set; }
        [DefaultValue(true)]
        public bool IsActive { get; set; } = true;

        
    }
}
