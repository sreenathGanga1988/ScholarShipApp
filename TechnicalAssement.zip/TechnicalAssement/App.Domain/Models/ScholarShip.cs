﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain.Models
{
     public  class ScholarShip : AuditEntity
    {

        public String Name { get; set; }
        public Boolean IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public DateTime? Approvedon { get; set; }

    }
}
