﻿using App.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace App.Domain.Interfaces
{
    public interface IScholarShipRepository : IGenericRepository<ScholarShip>
    {
        List<dynamic> GetSelectList(Expression<Func<ScholarShip, bool>> expression, int skip = 0, int nop = 0);

    }

    public interface IScholarShipApplicationRepository : IGenericRepository<ScholarShipApplication>
    {
       

    }
}
