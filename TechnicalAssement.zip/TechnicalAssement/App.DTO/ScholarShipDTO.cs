﻿using App.DTO.ModelDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain.Models
{
     public  class ScholarShipDTO : AuditEntity
    {

        public String Name { get; set; }
        public Boolean IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public string Approvedon { get; set; }
        public int IndividualID { get; set; }
        public int ScholarShipID { get; set; }
        public Boolean IsApplied { get; set; }
        public String Status { get; set; }
    }

    public partial class ScholarShipApplicationDTO : AuditEntity
    {
        public ScholarShipApplicationDTO()
        {

        }

        public int IndividualID { get; set; }
        public int ScholarShipID { get; set; }
        public Boolean IsApproved { get; set; }
        public string ApprovedBy { get; set; }
        public string ScholarShipName { get; set; }
        public string IndividualName { get; set; }
        public DateTime? Approvedon { get; set; }
       
    }
}
