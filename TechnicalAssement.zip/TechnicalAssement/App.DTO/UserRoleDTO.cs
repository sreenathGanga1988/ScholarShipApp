﻿using App.DTO.ModelDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace App.Domain.Models
{
    public class UserRoleDTO : AuditEntity
    {

        public String RoleName { get; set; }
        public String RoleSDescription { get; set; }
    }

}

