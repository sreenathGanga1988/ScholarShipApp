﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App.DTO.ModelDTO
{
    public class AuditEntity
    {
        public int ID { get; set; }
        public bool IsDeleted { get; set; } = false;
        public string DeletedUser { get; set; }
        public DateTime? AddedDate { get; set; }
        public string AddedUser { get; set; }
        public DateTime? Deleteddate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedUser { get; set; }
        public bool IsActive { get; set; } = true;

        public int? CreatedByUserId { get; set; }
        public int? ModifiedByUserId { get; set; }
        public int? DeletedByByUserId { get; set; }
    }
}
