﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using App.Domain.Interfaces;
using App.Domain.Models;
using System;

namespace WebApi.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class Api_SubmitApplicationController : BaseApiController
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;


        public Api_SubmitApplicationController(IUnitOfWork unitOfWork, IHttpContextAccessor contextAccessor, IMapper mapper) : base(contextAccessor)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;

        }

        // GET: api/ScholarShipApplication
        [HttpGet]
        [AllowAnonymous]
        public ActionResult<IEnumerable<ScholarShipApplication>> GetScholarShipApplication()
        {
            //purchaseDTORepository.getData();
            var k = _unitOfWork.ScholarShipApplicationRepository.GetAll();
            var items = _mapper.Map<IEnumerable<ScholarShipApplication>, IEnumerable<ScholarShipApplicationDTO>>(k);
            return Ok(items);
        }

        // POST: api/ScholarShipApplication
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        [AllowAnonymous]
        public ActionResult<ScholarShipApplication> PostScholarShipApplication(ScholarShipApplication ScholarShipApplication)
        {

            _unitOfWork.ScholarShipApplicationRepository.Add(ScholarShipApplication);
            _unitOfWork.SaveAllChanges();

            return CreatedAtAction("GetScholarShipApplication", new { id = ScholarShipApplication.ID }, ScholarShipApplication);
        }




        // GET: api/ScholarShipApplication/5
        [HttpGet("{id}")]
        [AllowAnonymous]
        public ActionResult<ScholarShipApplicationDTO> GetScholarShipApplication(int id)
        {





            var ScholarShipApplication = _unitOfWork.ScholarShipApplicationRepository.GetById(id);
            var _companydto = _mapper.Map<ScholarShipApplicationDTO>(ScholarShipApplication);
            if (_companydto == null)
            {
                return NotFound();
            }

            return _companydto;
        }


        // GET: api/ScholarShipApplication/5

        [AllowAnonymous]
        [HttpGet, Route("ApproveScholarShipApplication/{id}")]
        public ActionResult<ScholarShipApplicationDTO> ApproveScholarShipApplication(int id)
        {


            var ScholarShipApplication = _unitOfWork.ScholarShipApplicationRepository.GetById(id);
            ScholarShipApplication.IsApproved = true;
            ScholarShipApplication.Approvedon = DateTime.Now;

            _unitOfWork.ScholarShipApplicationRepository.Update(ScholarShipApplication);

            try
            {
                _unitOfWork.SaveAllChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_unitOfWork.ScholarShipApplicationRepository.DataExists(u => u.ID == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();



        }


        [AllowAnonymous]
        [HttpGet, Route("RejectScholarShipApplication/{id}")]
        public ActionResult<ScholarShipApplicationDTO> RejectScholarShipApplication(int id)
        {


            var ScholarShipApplication = _unitOfWork.ScholarShipApplicationRepository.GetById(id);
            ScholarShipApplication.IsApproved = false;
            ScholarShipApplication.Approvedon = DateTime.Now;

            _unitOfWork.ScholarShipApplicationRepository.Update(ScholarShipApplication);

            try
            {
                _unitOfWork.SaveAllChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_unitOfWork.ScholarShipApplicationRepository.DataExists(u => u.ID == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();



        }



        // PUT: api/ScholarShipApplication/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [AllowAnonymous]
        public IActionResult PutScholarShipApplication(int id, ScholarShipApplication ScholarShipApplication)
        {
            if (id != ScholarShipApplication.ID)
            {
                return BadRequest();
            }

            _unitOfWork.ScholarShipApplicationRepository.Update(ScholarShipApplication);

            try
            {
                _unitOfWork.SaveAllChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_unitOfWork.ScholarShipApplicationRepository.DataExists(u => u.ID == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        // DELETE: api/ScholarShipApplication/5
        [HttpDelete("{id}")]
        [AllowAnonymous]
        public ActionResult<ScholarShipApplication> DeleteScholarShipApplication(int id)
        {
            var ScholarShipApplication = _unitOfWork.ScholarShipApplicationRepository.GetById(id);
            if (ScholarShipApplication == null)
            {
                return NotFound();
            }

            _unitOfWork.ScholarShipApplicationRepository.Remove(ScholarShipApplication);
            _unitOfWork.SaveAllChanges();

            return ScholarShipApplication;
        }

        //private bool ScholarShipApplicationExists(int id)
        //{
        //    return _context.ScholarShipApplication.Any(e => e.Id == id);
        //}
    }

}



