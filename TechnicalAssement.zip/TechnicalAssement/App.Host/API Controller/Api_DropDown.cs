﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using System;

using System.Data;
using Newtonsoft.Json;
using App.Domain.Interfaces;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Api_DropDownController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

        public Api_DropDownController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }




        // GET: api/Data
        [HttpPost]
        public ActionResult<IEnumerable<dynamic>> GetData()
        {



            string q = Request.Form["q"].ToString();
            string pagestr = Request.Form["page"].ToString();
            string listType = Request.Form["listType"].ToString();
            string SearchTerm = Request.Form["dependentvalue"].ToString();
            int StoreID = int.Parse(Request.Form["StoreID"].ToString());
            int ParentId = int.Parse(Request.Form["ParentId"].ToString());

            
             







            int page = 0;

            if (pagestr.Trim().Length > 0)
            {
                page = int.Parse(pagestr);
            }

            int totalcount = 0;
            int NOP = 30;
            if (page > 0)
            {
                page -= 1;
            }
            if (string.Equals(listType.Trim(), "ScholorShip", StringComparison.OrdinalIgnoreCase))
            {
                totalcount = _unitOfWork.ScholarShipRepository .DataCount(u => u.Name.ToString().Contains(q) || u.ID.ToString().Contains(q));
                var data = _unitOfWork.ScholarShipRepository.GetSelectList(u => u.Name.Contains(q) || u.ID.ToString().Contains(q), NOP * page, NOP);
                return Ok(new { total_count = totalcount, items = data }); ;
            }
            
            else
            {
                return Ok(new { total_count = totalcount, items = "" }); ;
            }




        }




        public string DataTableToJSONWithJSONNet(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            return JSONString;
        }
       
    }
}
