﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using App.Domain.Interfaces;
using App.Domain.Models;
using System;

namespace WebApi.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    [ApiController]
    public class Api_ScholarShipController : BaseApiController
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;


        public Api_ScholarShipController(IUnitOfWork unitOfWork, IHttpContextAccessor contextAccessor, IMapper mapper) : base(contextAccessor)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;

        }

        // GET: api/ScholarShip
        [HttpGet]
        [AllowAnonymous]
        public ActionResult<IEnumerable<ScholarShip>> GetScholarShip()
        {
            //purchaseDTORepository.getData();
            var companys = _mapper.Map<IEnumerable<ScholarShip>, IEnumerable<ScholarShipDTO>>(_unitOfWork.ScholarShipRepository.GetAll());
            return Ok(companys);
        }

        // POST: api/ScholarShip
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        [AllowAnonymous]
        public ActionResult<ScholarShip> PostScholarShip(ScholarShip ScholarShip)
        {

            _unitOfWork.ScholarShipRepository.Add(ScholarShip);
            _unitOfWork.SaveAllChanges();

            return CreatedAtAction("GetScholarShip", new { id = ScholarShip.ID }, ScholarShip);
        }



        [AllowAnonymous]
        [HttpGet, Route("GetApprovedScholarShips/{id}")]
        public ActionResult<ScholarShipDTO> GetApprovedScholarShips(int id)
        {


            //purchaseDTORepository.getData();
            var companys = _mapper.Map<IEnumerable<ScholarShip>, IEnumerable<ScholarShipDTO>>(_unitOfWork.ScholarShipRepository.Find(U=>U.IsActive==true && U.IsApproved ==true));

            foreach (var item in companys)
            {


                var applctn = _unitOfWork.ScholarShipApplicationRepository.Find(u => u.ScholarShipID == item.ID && u.IndividualID == id);
                if (applctn != null)
                {

                    foreach (var app in applctn)
                    {
                        item.IsApplied = true;
                        item.Status = app.IsApproved ? "Approved" : "Rejected";
                    }
                    
                }
            }


            return Ok(companys);



        }



        // GET: api/ScholarShip/5
        [HttpGet("{id}")]
        [AllowAnonymous]
        public ActionResult<ScholarShipDTO> GetScholarShip(int id)
        {





            var ScholarShip = _unitOfWork.ScholarShipRepository.GetById(id);
            var _companydto = _mapper.Map<ScholarShipDTO>(ScholarShip);
            if (_companydto == null)
            {
                return NotFound();
            }

            return _companydto;
        }


        // GET: api/ScholarShip/5

        [AllowAnonymous]
        [HttpGet, Route("ApproveScholarShip/{id}")]
        public ActionResult<ScholarShipDTO> ApproveScholarShip(int id)
        {


            var ScholarShip = _unitOfWork.ScholarShipRepository.GetById(id);
            ScholarShip.IsApproved = true;
            ScholarShip.Approvedon = DateTime.Now;

            _unitOfWork.ScholarShipRepository.Update(ScholarShip);

            try
            {
                _unitOfWork.SaveAllChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_unitOfWork.ScholarShipRepository.DataExists(u => u.ID == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();        

          
        
        }



        // PUT: api/ScholarShip/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [AllowAnonymous]
        public IActionResult PutScholarShip(int id, ScholarShip ScholarShip)
        {
            if (id != ScholarShip.ID)
            {
                return BadRequest();
            }

            _unitOfWork.ScholarShipRepository.Update(ScholarShip);

            try
            {
                _unitOfWork.SaveAllChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_unitOfWork.ScholarShipRepository.DataExists(u => u.ID == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        // DELETE: api/ScholarShip/5
        [HttpDelete("{id}")]
        [AllowAnonymous]
        public ActionResult<ScholarShip> DeleteScholarShip(int id)
        {
            var ScholarShip = _unitOfWork.ScholarShipRepository.GetById(id);
            if (ScholarShip == null)
            {
                return NotFound();
            }

            _unitOfWork.ScholarShipRepository.Remove(ScholarShip);
            _unitOfWork.SaveAllChanges();

            return ScholarShip;
        }

        //private bool ScholarShipExists(int id)
        //{
        //    return _context.ScholarShip.Any(e => e.Id == id);
        //}
    }
    
}



