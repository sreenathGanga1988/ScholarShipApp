﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class BaseApiController : ControllerBase
    {

        public String CurrentUserName { get; set; }

        public int CurrentUserId { get; set; }
        public int CurrentStoreID { get; set; }

        public String CurrentUserRole { get; set; }

        public int CurrentFinanceYearID { get; set; }



        public BaseApiController(IHttpContextAccessor contextAccessor)
        {
            



            var identity = contextAccessor.HttpContext.User.Identity as ClaimsIdentity;
            if (identity != null)
            {
                IEnumerable<Claim> claims = identity.Claims;

                var userid = claims.Where(p => p.Type == "storeuserid").FirstOrDefault()?.Value;
                var storeid = claims.Where(p => p.Type == "storeid").FirstOrDefault()?.Value;
                var username = claims.Where(p => p.Type == "storeusername").FirstOrDefault()?.Value;
                var UsertTypeID = claims.Where(p => p.Type == "storeusertypeid").FirstOrDefault()?.Value;
                var storefinanceyear = claims.Where(p => p.Type == "storefinanceyear").FirstOrDefault()?.Value;


                try
                {
                    CurrentUserName = username;
                    CurrentUserId = int.Parse(userid);
                    CurrentStoreID = int.Parse(storeid);
                }
                catch (Exception)
                {
                    // Temporory to escape from  jwt error in demo remove it in furure

                    CurrentUserName = username;
                    CurrentUserId = 1;
                    CurrentStoreID = 3; ;
                }

            }




        }





    }
}
