﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using App.Domain.Interfaces;
using App.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using PosWebApp.Services;

namespace WebApi.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class SecurityController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IConfiguration _config;
        public SecurityController(IUnitOfWork unitOfWork , IConfiguration config)
        {
            _unitOfWork = unitOfWork;

            _config = config;
        }


        [HttpPost]
        public IActionResult Login([FromBody]UserLoginDTO loginDetails)
        {
            var  result = ValidateUser(loginDetails);
            if (result!=null)
            {

                JWTConfig jWTConfig = new JWTConfig();
                jWTConfig.Issuer = _config["Jwt:Issuer"];
                jWTConfig.Audience = _config["Jwt:Audience"];
                jWTConfig.Key = _config["Jwt:Key"];


                result= SecurityService.JWTAuthentication(result, jWTConfig);

                return Ok(new { token = result.Token, userName = result.UserName, id = result.ID, UsertTypeID =result.UsertTypeID });
            }
            else
            {
                return Unauthorized();
            }
        }
       



        private UserDTO ValidateUser(UserLoginDTO loginDetails)
        {

             var k = _unitOfWork.IndividualRepository.Find(u => u.UserName == loginDetails.UserName && u.Password == loginDetails.Password && u.IsActive==true).FirstOrDefault ();
            try
            {
                UserDTO userDTO = new UserDTO();
                userDTO.ID = k.ID;
                userDTO.UserName = k.UserName;
               
                userDTO.Email = k.Email;
                userDTO.UsertTypeID = k.UserRoleID.ToString ();
                
                return userDTO;

                //var k = _unitOfWork.User.GetLoginUser(loginDetails.UserName, loginDetails.Password);

                //if (k != null)
                //{

                //    UserDTO userDTO = new UserDTO();
                //    userDTO.ID = k.ID;
                //    userDTO.UserName = k.UserName;
                //    userDTO.StoreID = k.StoreID;
                //    userDTO.Email = k.Email;
                //    userDTO.UsertTypeID = k.UsertTypeID;
                //    userDTO.CurrentFinanceYearID = financeyear.ID
                //    var financeyear = _unitOfWork.FinancialYear.Find(u => u.StoreID == userDTO.StoreID && u.IsActive == true).FirstOrDefault();

                //    if (financeyear != null)
                //    {
                //        userDTO.CurrentFinanceYearID = financeyear.ID;
                //    }
                //    else
                //    {
                //        userDTO.CurrentFinanceYearID = 0;
                //    }
                //    return userDTO;

                //}
                //else
                //{
                //    return null;
                //}
            }
            catch (Exception ex)
            {

               
                return null;
            }


        }




    }

    public class UserLoginDTO
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class JWTConfig
    {
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string Key { get; set; }
    }

}