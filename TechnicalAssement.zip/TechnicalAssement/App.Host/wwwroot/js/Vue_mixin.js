﻿var mixinArray = [];

const DropDownMixin = {
    methods: {
        clicked() {
            alert("WORK!")
        },
        onQuestionSearch(search, loading) {
            this.GenerateDropDowns('QUESTION', search, 0, 0)
        },
       

        GenerateDropDowns: function (listType, search, StoreID, ParentId) {

            if (typeof StoreID === 'undefined') {

                StoreID = 0;
                // color is undefined
            }
            if (typeof ParentId === 'undefined') {

                ParentId = 0;
                // color is undefined
            }


            var bodyFormData = new FormData();
            bodyFormData.append('listType', listType);
            bodyFormData.append('q', search);
            bodyFormData.append('StoreID', StoreID);
            bodyFormData.append('ParentId', ParentId);




            axios({
                method: 'post',
                url: '/api/Api_DropDown/',
                data: bodyFormData,
                headers: { 'Content-Type': 'multipart/form-data' }
            })
                .then(function (response) {
                    //handle success


                    if (listType === 'QUESTION') {
                        this.allquestions = response.data.items;
                    }



                   



                }.bind(this))
                .catch(function (response) {
                    //handle error
                    console.log(response);
                });
        },



        StartProgress: function () {
            this.showProgress = true;

        },

        StopProgress: function () {

            this.showProgress = false;

        },

        IsEmpty: function (val) {

            return (val === undefined || val == null || val.length <= 0) ? true : false;

        },



    }
}
const AxiosMixin = {
    data: {
        responsedata: [],
        isSuccess: false,
        message: '',
    },
    methods: {

        Axios_GET_LIST: function (apiurl) {
            this.StartProgress();

            axios({
                method: 'get',
                url: apiurl,
                headers: { 'Authorization': 'Bearer ' + this.getmyCookie("Jwttok") }
            }).then((response) => {
                console.log(Response);

                this.list = response.data
                this.StopProgress();

            }).catch((error) => {
                console.log(error);
                this.StopProgress();
            }).then(function () {


            });
        },
        Axios_GET: function (apiurl) {
            this.StartProgress();

            return axios({
                method: 'get',
                url: apiurl,
                headers: { 'Authorization': 'Bearer ' + this.getmyCookie("Jwttok") }
            }).then((response) => {

                this.StopProgress();
                return response;
            }).catch((error) => {
                this.StopProgress();
                console.log(error);
            });
        },

        Axios_POST: function (apiurl, objdata, callback) {
            this.StartProgress();
            return axios({
                method: 'post',
                headers: { 'Authorization': 'Bearer ' + this.getmyCookie("Jwttok") },
                data: objdata,
                url: apiurl

            }).then((response) => {

                this.StopProgress();

                if (callback) {
                    callback(response);
                }
                return response;
            }).catch((error) => {
                this.StopProgress();
                console.log(error);
            });
        },


        Axios_PUT: function (apiurl, objdata, callback) {
            this.StartProgress();
            return axios({
                method: 'put',
                headers: { 'Authorization': 'Bearer ' + this.getmyCookie("Jwttok") },
                data: objdata,
                url: apiurl
            }).then((response) => {

                this.StopProgress();

                if (callback) {
                    callback(response);
                }
            }).catch((error) => {
                this.StopProgress();
                console.log(error);
            });
        },


        Axios_DELETE: function (apiurl, callback) {
            this.StartProgress();
            return axios({
                method: 'delete',
                headers: { 'Authorization': 'Bearer ' + this.getmyCookie("Jwttok") },
                url: apiurl
            }).then((response) => {

                this.StopProgress();

                if (callback) {
                    callback(response);
                }
            }).catch((error) => {
                this.StopProgress();
                console.log(error);
            });
        },


        getmyCookie(name) {
            // it gets the cookie called `username`

            let authcockiee = "";
            let decodedCookie = decodeURIComponent(document.cookie);

            // Get all cookies, split on ; sign
            let cookies = decodedCookie.split(';');

            // Loop over the cookies
            for (let i = 0; i < cookies.length; i++) {
                // Define the single cookie, and remove whitespace
                let cookie = cookies[i].trim();

                // If this cookie has the name of what we are searching
                if (cookie.indexOf(name) == 0) {
                    // Return everything after the cookies name
                    authcockiee = cookie.substring(name.length + 1, cookie.length);
                }
            }


            return authcockiee;


        }




    }
}




const NotificationMixin = {
    data: {

    },
    methods: {

        ShowErrorNotification: function (msg) {
            this.ShowNotify(msg, "error");
        },
        ShowSuccessNotification: function (msg) {
            this.ShowNotify(msg, "success");
        },
        ShowInfoNotification: function (msg) {
            this.ShowNotify(msg, "info");
        },
        ShowNotify: function (msg, type) {
            new Noty({
                type: type,
                layout: 'topRight',
                theme: 'sunset',
                text: msg,
                timeout: '4000',
                progressBar: true,
                closeWith: ['click'],
                killer: true,
                callbacks: {
                    beforeShow: function () {

                    },
                    onShow: function () {

                    },
                    onHover: function () {

                    },
                    onClick: function () {

                    },
                    onClose: function () {

                    }
                },
            }).show();
        }
    }
}







mixinArray.push(DropDownMixin);
mixinArray.push(AxiosMixin);
mixinArray.push(NotificationMixin);