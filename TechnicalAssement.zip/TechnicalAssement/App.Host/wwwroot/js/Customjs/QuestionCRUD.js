﻿var pageMixin = {
    mounted() {
        this.ShowListScreen();
    },
    created() {

    },
    data: {
        list: [],
        itemToEdit: null,
        itemToView: null,
        itemToDelete: null,
        MODE: '',
        id: 0,
        fullQuestion: '',
        answerOption1: '',
        answerOption2: '',
        answerOption3: '',
        answerOption4: '',
        correctAnswer: '',
        isMultiple:"0",
        mark: 1,
        isDeleted: false,        
        isActive: true,
        LogoUrl:'',
        sucessmessages: []    
    },
    methods: {


        ShowListScreen: function () {
            this.appMessage = "QUESTIONS";
            this.list = [];
            this.MODE = 'LIST_MODE'
            this.ShowList();

        },
      
        ShowList: function () {
            
            return this.Axios_GET('/api/Api_Question').then((response) => {
                this.list = response.data;
                this.initDatatable();
            });

        },

        ShowAddScreen: function () {
            this.destroyDatatable();
            this.appMessage = "ADD QUESTION";
            this.MODE = 'ADD_MODE'
        },
        AddNew: function (e) {
            this.errors = [];
           
            if (!this.fullQuestion) {
                this.errors.push(" Question required.");
            }
            if (!this.answerOption1) {
                this.errors.push(" Option 1 required.");
            }
            if (!this.answerOption2) {
                this.errors.push(" Option 2 required.");
            }
            if (!this.answerOption3) {
                this.errors.push(" Option 3 required.");
            }
            if (!this.answerOption4) {
                this.errors.push(" Option 4 required.");
            }
            if (!this.correctAnswer) {
                this.errors.push(" Correct Answer required.");
            }

            if (this.isMultiple === "1") {
                this.isMultiple = true;
            } else {
                this.isMultiple = false;
            }





            if (!this.errors.length) {
                let question = {
                    id: 0,
                    fullQuestion: this.fullQuestion,
                    answerOption1: this.answerOption1,
                    answerOption2: this.answerOption2,
                    answerOption3: this.answerOption3,
                    answerOption4: this.answerOption4,
                    correctAnswer: this.correctAnswer,
                    mark: this.mark,
                    isMultiple: this.isMultiple,
                    isActive: this.isActive,
                    isDeleted: this.isDeleted,
                    addedDate: new Date(),
                };

                return this.Axios_POST('/api/Api_Question', question, this.ShowListScreen).then((response) => {
                    this.fullQuestion = '';
                    this.answerOption1 = '';
                    this.answerOption2 = '';
                    this.answerOption3 = '';
                    this.answerOption4 = '';
                    this.correctAnswer = '';

                });

              
            }

        },


        EditItem: function (id) {
            
            this.appMessage = "EDIT QUESTION";
            this.destroyDatatable();
            return this.Axios_GET('/api/Api_Question/' + id).then((response) => {
                console.log(Response);
                this.itemToEdit = response.data;
                this.MODE = 'EDIT_MODE'
            });

        },
        UpdateItem: function (e) {
            this.errors = [];



            if (!this.itemToEdit.fullQuestion) {
                this.errors.push(" Question required.");
            }
            if (!this.itemToEdit.answerOption1) {
                this.errors.push(" Option 1 required.");
            }
            if (!this.itemToEdit.answerOption2) {
                this.errors.push(" Option 2 required.");
            }
            if (!this.itemToEdit.answerOption3) {
                this.errors.push(" Option 3 required.");
            }
            if (!this.itemToEdit.answerOption4) {
                this.errors.push(" Option 4 required.");
            }
            if (!this.itemToEdit.correctAnswer) {
                this.errors.push(" Correct Answer required.");
            }

            if (this.itemToEdit.isMultiple === "1") {
                this.itemToEdit.isMultiple = true;
            } else {
                this.itemToEdit.isMultiple = false;
            }

            if (!this.errors.length) {
                let question = this.itemToEdit;
                question.modifiedDate = new Date();

               

                return this.Axios_PUT('/api/Api_Question/' + question.id, question, this.ShowListScreen).then((response) => {
                /*  this.list = response.data;*/
                   
                });
            }

        },


        ViewItem: function (id) {
            console.log(this.itemToView);
            this.destroyDatatable();
          
            this.appMessage = "VIEW QUESTION";
            return this.Axios_GET('/api/Api_Question/' + id).then((response) => {
                console.log(Response);
                this.itemToView = response.data;
                this.MODE = 'VIEW_MODE';
                console.log(this.itemToView);
            });


        },

        DeleteItem: function (id) {
            this.destroyDatatable();
            console.log(this.itemToDelete);
            this.appMessage = "DELETE QUESTION";
            return this.Axios_GET('/api/Api_Question/' + id).then((response) => {
                console.log(Response);
                this.itemToDelete = response.data;
                this.MODE = 'DELETE_MODE';
                console.log(this.itemToDelete);
            });

        
        
        },

        ConfirmDeleteItem: function (id) {
            this.Axios_DELETE('/api/Api_Question/' + id, this.ShowListScreen);  
        },
    }
};

mixinArray.push(pageMixin);