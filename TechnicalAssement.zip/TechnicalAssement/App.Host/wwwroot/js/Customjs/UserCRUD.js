﻿var pageMixin = {
    mounted() {
        this.ShowListScreen();
    },
    created() {

    },
    data: {
        list: [],
        itemToEdit: null,
        itemToView:null,
        MODE: '',

        id: 0,
        UserName: '',
        Password: '',
        Email: '',
        UsertTypeID: '',
        StoreID: '',
        isDeleted: false,
       
        isActive: true,

        errors: [],
        sucessmessages: [],

         stores: [],
    },
    methods: {


        ShowListScreen: function () {
            this.MODE = 'LIST_MODE'
            this.ShowList();
        },
        ShowList: function () {
            return this.Axios_GET('/api/Api_User').then((response) => {               
                this.list = response.data;
                this.initDatatable();
            });

        },
  
   
        ShowAddScreen: function () {
            this.destroyDatatable();
            this.MODE = 'ADD_MODE'
            this.GenerateDropDowns("STORE"," ");
        },
        AddNew: function (e) {
            this.errors = [];
            if (!this.UserName) {
                this.errors.push(" User Name required.");
            }
            if (!this.Password) {
                this.errors.push(" PassWord required.");
            }
            if (!this.Email) {
                this.errors.push(" Email is required.");
            }
            if (!this.UsertTypeID) {
                this.errors.push(" UserType required.");
            }
            if (!this.StoreID) {
                this.errors.push(" Store required.");
            }

          
            if (!this.errors.length) {
                let store = {
                    id: 0,
                    UserName: this.UserName,
                    Email: this.Email,
                    Password: this.Password,
                    UsertTypeID: this.UsertTypeID,
                    storeID:parseInt( this.StoreID),
                    isActive: this.isActive,
                    isDeleted: this.isDeleted,
                    addedDate: new Date(),
                };
                   return this.Axios_POST('/api/Api_User', store, this.ShowListScreen).then((response) => {
                       this.UserName = '';
                       this.Password = '';
                       this.UsertTypeID = '';
                       this.storeID = '';
                       this.Email = '';
                    

                });


            }

        },

        EditItem: function (id) {

            this.destroyDatatable();

            return this.Axios_GET('/api/Api_User/' + id).then((response) => {
                console.log(Response);
                this.itemToEdit = response.data;
                this.MODE = 'EDIT_MODE';
                this.StoreID = this.itemToEdit.storeID;
                this.GenerateDropDowns("STORE", this.itemToEdit.storeID);
            });
        },
        UpdateItem: function (e) {
            this.errors = [];

            if (!this.itemToEdit.UserName) {
                this.errors.push(" User Name required.");
            }
            if (!this.itemToEdit.Password) {
                this.errors.push(" PassWord required.");
            }
            if (!this.itemToEdit.Email) {
                this.errors.push(" Email is required.");
            }
            if (!this.itemToEdit.UsertTypeID) {
                this.errors.push(" UserType required.");
            }
            if (!this.itemToEdit.StoreID) {
                this.errors.push(" Store required.");
            }
            
            if (!this.errors.length) {
                let user = this.itemToEdit;
                user.modifiedDate = new Date();

               
               
                if (this.itemToEdit.storeID.code) {
                    user.storeID = parseInt(this.itemToEdit.storeID.code);
                }
                else {
                    user.storeID = parseInt(this.itemToEdit.storeID);
                }
                return this.Axios_PUT('/api/Api_User/' + user.id, user, this.ShowListScreen).then((response) => {
                    /*  this.list = response.data;*/

                });

            }

        },
        

        ViewItem: function (id) {
            this.destroyDatatable();
            console.log(this.itemToView);
            return this.Axios_GET('/api/Api_User/' + id).then((response) => {
                console.log(Response);
                this.itemToView = response.data;
                this.MODE = 'VIEW_MODE';
                console.log(this.itemToView);
            });

        },

        DeleteItem: function (id) {
            this.destroyDatatable();
            console.log(this.itemToDelete);
            return this.Axios_GET('/api/Api_User/' + id).then((response) => {
                console.log(Response);
                this.itemToDelete = response.data;
                this.MODE = 'DELETE_MODE';
                console.log(this.itemToDelete);
            });

        },

        ConfirmDeleteItem: function (id) {
            this.Axios_DELETE('/api/Api_User/' + id, this.ShowListScreen);  
        },



      
        SetSelectedCompanies: function () {

            this.itemToEdit.storeID = this.stores.find(item => item.code == this.StoreID);

            //this.itemToEdit.storeID = parseInt(this.itemToEdit.storeID.code);


           
           

        },

    }
};

mixinArray.push(pageMixin);