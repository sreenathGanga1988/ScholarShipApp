﻿using App.Domain.Models;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.Host.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
          //  CreateMap<TestClass, TestClassDTO>();
        }
    }
    

}
