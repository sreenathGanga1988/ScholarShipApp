using System;
using System.Data;
using System.Text;
using App.Domain.Interfaces;
using App.EfCore;
using App.EfCore.Repositories;
using DataAccess.EFCore.UnitOfWorks;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using PosWebApp.ViewModels;


namespace PosWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            BuildAppSettingsProvider();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddControllersWithViews().AddRazorRuntimeCompilation ();            
            services.AddSession();
            services.AddMemoryCache();
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
      .AddCookie(options =>
      {
          options.LoginPath = "/Home/login/";
          options.AccessDeniedPath = "/Home/Login/";
      })      .AddJwtBearer(options =>
       {
           options.TokenValidationParameters = new TokenValidationParameters
           {
               ValidateIssuer = true,
               ValidateAudience = true,
               ValidateLifetime = true,
               ValidateIssuerSigningKey = true,
               ValidIssuer = Configuration["Jwt:Issuer"],
               ValidAudience = Configuration["Jwt:Audience"],
               IssuerSigningKey = new SymmetricSecurityKey
             (Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
           };
       });
            services.AddDbContext<AppWebDataContext>(options =>
          options.UseLazyLoadingProxies(). UseSqlServer(Configuration.GetConnectionString("AppWebDataContext")));
            services.AddTransient<IDbConnection>((sp) =>
          new SqlConnection(this.Configuration.GetConnectionString("AppWebDataContext")));

            services.AddHttpContextAccessor();
            services.AddTransient(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            
            services.AddTransient<IUnitOfWork, UnitOfWork>();
    
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                AppSettingsProvider.BaseApiUri = Configuration["BaseApiUriDEV"];
                AppSettingsProvider.IsDevelopment = true;
            }
            else
            {
                // app.UseExceptionHandler("/Home/Error");
                app.UseDeveloperExceptionPage(); //REMOVE THIS LATER
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseSession();
            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {

 

                endpoints.MapAreaControllerRoute(
          name: "Admin",
          areaName: "Admin",
          pattern: "Admin/{controller=Home}/{action=Index}/{id?}");

                endpoints.MapAreaControllerRoute(
     name: "OnlineStudent",
     areaName: "OnlineStudent",
     pattern: "OnlineStudent/{controller=Home}/{action=Index}/{id?}");

                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");

                endpoints.MapControllers();
            });

        
        }

        private void BuildAppSettingsProvider()
        {
            AppSettingsProvider.BaseApiUri = Configuration["BaseApiUri"];

        }
    }
}
