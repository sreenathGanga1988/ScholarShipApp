﻿using App.Domain.Models;
using AutoMapper;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace PosWebApp.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {

            CreateMap<ScholarShip, ScholarShipDTO>();
            CreateMap<ScholarShipApplication, ScholarShipDTO>().ForMember(dest => dest.ID, source => source.MapFrom(source => source.ScholarShipID));
            CreateMap<ScholarShipApplication, ScholarShipApplicationDTO>().ForMember(dest => dest.ScholarShipName, source => source.MapFrom(source => source.ScholarShip.Name))
                .ForMember(dest => dest.IndividualName, source => source.MapFrom(source => source.Individual.FullName));
            //CreateMap<User, UserDTO>();

            //CreateMap<ExamQuestion, ExamQuestionDTO >();

            //CreateMap<ExamQuestion, ExamQuestionDTO>()
            //  .ForMember(dest => dest.FullQuestion, source => source.MapFrom(source => source.Question.FullQuestion))
            //   .ForMember(dest => dest.AnswerOption1, source => source.MapFrom(source => source.Question.AnswerOption1))
            //    .ForMember(dest => dest.AnswerOption2, source => source.MapFrom(source => source.Question.AnswerOption2))
            //    .ForMember(dest => dest.AnswerOption3, source => source.MapFrom(source => source.Question.AnswerOption3))
            //    .ForMember(dest => dest.AnswerOption4, source => source.MapFrom(source => source.Question.AnswerOption4))
            //    .ForMember(dest => dest.CorrectAnswer, source => source.MapFrom(source => source.Question.CorrectAnswer))
            //    .ForMember(dest => dest.isMultiple, source => source.MapFrom(source => source.Question.isMultiple))

            //           .ForMember(dest => dest.Mark, source => source.MapFrom(source => source.Question.Mark))                ;

            //CreateMap<Exam, ExamDTO >();

            //CreateMap<CandidateExamDetail, CandidateExamDetailDTO>();
            //CreateMap<CandidateExam, CandidateExamDTO >();





            // CreateMap<Company, CompanyDTO>();
            // CreateMap<User, UserDTO>().ForMember(dest => dest.StoreName , source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<Category, CategoryDTO>();
            // CreateMap<ItemName , ItemNameDTO >().ForMember(dest => dest.CategoryName, source => source.MapFrom(source => source.Category.CategoryName));
            // CreateMap<Customer, CustomerDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<ExpenseItem, ExpenseItemDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<FinancialYear, FinancialYearDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<PaymentModeMaster, PaymentModeMasterDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<VoucherMaster, VoucherMasterDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));
            // CreateMap<SalesMen, SalesMenDTO>()
            //.ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName))
            // .ForMember(dest => dest.CustomerName, source => source.MapFrom(source => source.Customer.CustomerName))
            //   .ForMember(dest => dest.UserName, source => source.MapFrom(source => source.User.UserName.ToString()));

            // CreateMap<PurchaseInvoiceDetail, PurchaseInvoiceDetailDTO>()
            //     .ForMember(dest => dest.CategoryName, source => source.MapFrom(source => source.Category.CategoryName))
            //      .ForMember(dest => dest.ItemDesc, source => source.MapFrom(source => source.ItemName.ItemDesc));

            // CreateMap<PurchaseInvoicemaster, PurchaseInvoicemasterDTO>()
            //     .ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName))
            //      .ForMember(dest => dest.CustomerName, source => source.MapFrom(source => source.Customer.CustomerName));



            // CreateMap<PurchaseInvoicemaster, PurchaseInvoicemasterDTOList>();




            // //CreateMap<PurchaseInvoicemaster, PurchaseInvoicemasterDTOList>()
            // // .ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName))
            // //  .ForMember(dest => dest.CustomerName, source => source.MapFrom(source => source.Customer.CustomerName))
            // //    .ForMember(dest => dest.ItemCount, source => source.MapFrom(source => source.PurchaseInvoiceDetails.Count.ToString()));


            // CreateMap<Product, ProductListDTO>()
            // .ForMember(dest => dest.SellingPrice, source => source.MapFrom(source => source.UnitSp))
            //  .ForMember(dest => dest.CostPrice, source => source.MapFrom(source => source.UnitCp));



            // //CreateMap<InvoiceDetail, InvoiceDetailDTO>()
            // // .ForMember(dest => dest.CategoryName, source => source.MapFrom(source => source.Product.Category.CategoryName))
            // //  .ForMember(dest => dest.ItemDesc, source => source.MapFrom(source => source.Product.ItemName.ItemDesc))
            // //   .ForMember(dest => dest.ProductName, source => source.MapFrom(source => source.Product.ProductName))
            // //    .ForMember(dest => dest.SerialNum, source => source.MapFrom(source => source.Product.SerialNum));

            // CreateMap<InvoiceDetail, InvoiceDetailDTO>();



            // CreateMap<InvoiceMaster, InvoiceMasterDTO>()
            //   .ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName))
            //    .ForMember(dest => dest.CustomerName, source => source.MapFrom(source => source.Customer.CustomerName))
            //     .ForMember(dest => dest.VoucherName, source => source.MapFrom(source => source.VoucherMaster.VoucherName))
            //      .ForMember(dest => dest.VoucherImgSrc, source => source.MapFrom(source => source.VoucherMaster.VoucherImgSrc))
            //     .ForMember(dest => dest.PaymentMode, source => source.MapFrom(source => source.PaymentModeMaster.PaymentMode))
            //     .ForMember(dest => dest.SalesManName, source => source.MapFrom(source => source.SalesMan.SalesMenName))
            //     .ForMember(dest => dest.LogoUrl, source => source.MapFrom(source => source.Store.Company.LogoUrl));


            // CreateMap<InvoiceMaster, InvoiceMasterDTOList>()
            //    .ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName))
            //     .ForMember(dest => dest.CustomerName, source => source.MapFrom(source => source.Customer.CustomerName))
            //      .ForMember(dest => dest.VoucherName, source => source.MapFrom(source => source.VoucherMaster.VoucherName))
            //      .ForMember(dest => dest.PaymentMode, source => source.MapFrom(source => source.PaymentModeMaster.PaymentMode))
            //      .ForMember(dest => dest.SalesManName, source => source.MapFrom(source => source.SalesMan.SalesMenName));





            // CreateMap<ExpenseDetail, ExpenseDetailDTO>().ForMember(dest => dest.StoreName, source => source.MapFrom(source => source.Store.StoreName));









        }
    }
}
 