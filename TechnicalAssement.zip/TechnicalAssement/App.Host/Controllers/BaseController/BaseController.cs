﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PosWebApp.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class BaseController : Controller
    {




        public String CurrentUserName { get; set; }

        public int CurrentUserId { get; set; }
        public int CurrentStoreID { get; set; }
 
        public String CurrentUserRole { get; set; }

        public int CurrentFinanceYearID { get; set; }
        public String JWTTokenstring { get; set; }


        public BaseController(IHttpContextAccessor contextAccessor)
        {


            


            CurrentUserName = contextAccessor.HttpContext.User.FindFirst(ClaimTypes.Name)?.Value;

            var CurrentUser = contextAccessor.HttpContext.User.FindFirst(ClaimTypes.SerialNumber)?.Value;
            if (CurrentUser != null)
            {
                CurrentUserId = int.Parse(CurrentUser.ToString());
            }

            
        


          





        }


    }
}
