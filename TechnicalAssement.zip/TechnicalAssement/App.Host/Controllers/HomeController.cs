﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using App.DTO;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using PosWebApp.Models;
using PosWebApp.Services;
using PosWebApp.ViewModels;

namespace PosWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Login()
        {
            return View();
        }
        [AllowAnonymous]
        // POST: Category/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(UserDTO userModel)
        {
            HttpResponseMessage response = await HttpTaskService.PostAsyncwithoutheader("/api/security", userModel);
            if (response.StatusCode == HttpStatusCode.OK)
            {
                string stringJWT = response.Content.ReadAsStringAsync().Result;


                UserDTO userDTO = JsonConvert.DeserializeObject<UserDTO>(stringJWT);
                var authdet = SecurityService.TokenAuthentication(userDTO.Token);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(authdet.claimsIdentity), authdet.authenticationProperties);

              
                    CookieOptions option = new CookieOptions();                   
                    option.Expires = DateTime.Now.AddMinutes(30);
                    Response.Cookies.Append("Jwttok", userDTO.Token, option);
              

             
                TempData["SucessAlert"] = "User logged in successfully!";


                if(userDTO.UsertTypeID == "2")
                {
                    return RedirectToAction("Index", "Home", new { area = "Admin" });
                }
                else
                {
                    return RedirectToAction("Index", "Home", new { area = "OnlineStudent" });
                }
              
           


            }
            else
            {
                TempData["ErrorAlert"] = "Invalid User Name & Password: Try Again";
                return RedirectToAction("Login");
            }








        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            Response.Cookies.Delete("Jwttok");           
            TempData["SucessAlert"] = "User logged out successfully!";
            return RedirectToAction("Login");

        }



        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    public class TokenAuthenticationProps{
        public AuthenticationProperties authenticationProperties { get; set; }
        public ClaimsIdentity claimsIdentity { get; set; }
        

    }

}
