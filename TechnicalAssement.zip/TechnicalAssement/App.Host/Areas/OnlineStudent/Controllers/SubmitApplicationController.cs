﻿using App.Domain.Interfaces;
using AutoMapper;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PosWebApp.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.Host.Areas.OnlineStudent.Controllers
{
    [Area("OnlineStudent")]
    public class SubmitApplicationController : BaseController
    {
        private readonly ILogger<SubmitApplicationController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        public SubmitApplicationController(IUnitOfWork unitOfWork, IMapper mapper, ILogger<SubmitApplicationController> logger, IHttpContextAccessor contextAccessor) : base(contextAccessor)
        {
            _logger = logger;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        [AllowAnonymous]
        public IActionResult Index()
        {
            ViewBag.CurrentUserId = CurrentUserId;
            ViewBag.CurrentUserName = CurrentUserName;

           

            return View();
        }
    }
}