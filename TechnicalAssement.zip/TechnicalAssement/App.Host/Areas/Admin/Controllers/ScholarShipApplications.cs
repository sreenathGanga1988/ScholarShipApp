﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PosWebApp.Models;
namespace PosWebApp.Controllers
{
    [Area("Admin")]
    public class ScholarShipApplicationController : BaseController
    {
        private readonly ILogger<ScholarShipApplicationController> _logger;

        public ScholarShipApplicationController(ILogger<ScholarShipApplicationController> logger, IHttpContextAccessor contextAccessor) : base(contextAccessor)
        {
            _logger = logger;

        }

        public IActionResult Index()
        {
            ViewData["CurrentUserId"] = CurrentUserId;
        

            return View();
        }
        public IActionResult Create()
        {
          

            return View();
        }
        public IActionResult Delete(int id)
        {
           
            return View();
        }

        public IActionResult Details(int id)
        {
           

            return View();
        }

      
        public IActionResult Result(int id)
        {
            
            return View();
        }

    }
}
