﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PosWebApp.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PosWebApp.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, IHttpContextAccessor contextAccessor) : base(contextAccessor)
        {
            _logger = logger;

        }
        [Authorize]
        public IActionResult Index()
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;

            return View();
        }
    }
}
