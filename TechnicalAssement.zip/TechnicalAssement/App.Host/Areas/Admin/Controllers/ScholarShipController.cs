﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PosWebApp.Models;
namespace PosWebApp.Controllers
{
    [Area("Admin")]
    public class ScholarShipController : BaseController
    {
        private readonly ILogger<ScholarShipController> _logger;

        public ScholarShipController(ILogger<ScholarShipController> logger, IHttpContextAccessor contextAccessor) : base(contextAccessor)
        {
            _logger = logger;

        }

        public IActionResult Index()
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;
            ViewData["CurrentFinanceYearID"] = CurrentFinanceYearID;

            return View();
        }
        public IActionResult Create()
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;
            ViewData["CurrentFinanceYearID"] = CurrentFinanceYearID;

            return View();
        }
        public IActionResult Delete(int id)
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;
            ViewData["CurrentFinanceYearID"] = CurrentFinanceYearID;
            ViewData["ID"] = id;
            return View();
        }

        public IActionResult Details(int id)
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;
            ViewData["CurrentFinanceYearID"] = CurrentFinanceYearID;
            ViewData["Id"] = id;

            return View();
        }

      
        public IActionResult Result(int id)
        {
            ViewData["CurrentUserId"] = CurrentUserId;
            ViewData["CurrentStoreID"] = CurrentStoreID;
            ViewData["CurrentUserRole"] = CurrentUserRole;
            ViewData["CurrentUserName"] = CurrentUserName;
            ViewData["CurrentFinanceYearID"] = CurrentFinanceYearID;
            ViewData["Id"] = id;

            return View();
        }

    }
}
