﻿using App.DTO;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using PosWebApp.Controllers;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebApi.Controllers;

namespace PosWebApp.Services
{
    public static class SecurityService
    {







        public static UserDTO JWTAuthentication(UserDTO result, JWTConfig jWTConfig)
        {
          
            var claims = new[]
            {   new Claim(JwtRegisteredClaimNames.NameId,result.ID.ToString ()) ,
                   
                    new Claim(JwtRegisteredClaimNames.UniqueName,result.UserName.ToString ()) ,
                    new Claim(JwtRegisteredClaimNames.Typ,result.UsertTypeID.ToString ()) ,                    
                     new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString ()),
                       new Claim("storeuserid",result.ID.ToString ()),
                          new Claim("storeusername",result.UserName.ToString ()),                             
                             new Claim("storeusertypeid",result.UsertTypeID.ToString ()),
            };
            var issuer = jWTConfig.Issuer;
            var audience = jWTConfig.Audience;
            var expiry = DateTime.Now.AddMinutes(120);
            var securityKey = new SymmetricSecurityKey
           (Encoding.UTF8.GetBytes(jWTConfig.Key));
            var credentials = new SigningCredentials
        (securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                claims: claims,
        audience: audience,
        expires: DateTime.Now.AddMinutes(120),
        signingCredentials: credentials);

            var tokenHandler = new JwtSecurityTokenHandler();
            var stringToken = tokenHandler.WriteToken(token);

            result.Token = stringToken;
            return result;
        }


       
        public static TokenAuthenticationProps TokenAuthentication(String stringJWT)
        {
            
            var tokenrev = new JwtSecurityTokenHandler().ReadJwtToken(stringJWT);

            var userid = tokenrev.Claims.First(c => c.Type == "nameid").Value; // UserID
      
            var username = tokenrev.Claims.First(c => c.Type == "unique_name").Value; //username
            var UsertTypeID = tokenrev.Claims.First(c => c.Type == "typ").Value; //usertype    
              


         
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, username),
                  new Claim(ClaimTypes.SerialNumber, userid),
                  new Claim(ClaimTypes.Role, UsertTypeID),
                    new Claim(ClaimTypes.GivenName, userid),
                   
            };
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);



            var authProperties = new AuthenticationProperties
            {
                //AllowRefresh = <bool>,
                // Refreshing the authentication session should be allowed.

                //ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10),
                // The time at which the authentication ticket expires. A 
                // value set here overrides the ExpireTimeSpan option of 
                // CookieAuthenticationOptions set with AddCookie.

                //IsPersistent = true,
                // Whether the authentication session is persisted across 
                // multiple requests. When used with cookies, controls
                // whether the cookie's lifetime is absolute (matching the
                // lifetime of the authentication ticket) or session-based.

                //IssuedUtc = <DateTimeOffset>,
                // The time at which the authentication ticket was issued.

                //RedirectUri = <string>
                // The full path or absolute URI to be used as an http 
                // redirect response value.
            };

            TokenAuthenticationProps tokenAuthenticationProps = new TokenAuthenticationProps();

             tokenAuthenticationProps.authenticationProperties = authProperties;
            tokenAuthenticationProps.claimsIdentity = claimsIdentity;


            return tokenAuthenticationProps;

           
        }

      
    }
}
