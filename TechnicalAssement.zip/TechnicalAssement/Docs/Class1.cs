﻿using System;

namespace Docs
{
    public class Class1
    {
    }
}
