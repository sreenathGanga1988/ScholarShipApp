﻿
using App.Domain.Interfaces;
using App.EfCore;
using App.EfCore.Repositories;
using System;
using System.Data;

namespace DataAccess.EFCore.UnitOfWorks
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppWebDataContext _context;
        private readonly IDbConnection _dbConnection;


        public IIndividualRepository StudentRepository { get; private set; }
        public IScholarShipRepository ScholarShipRepository { get; private set; }
        public IAdminRepository AdminRepository { get; private set; }
        public IIndividualRepository IndividualRepository { get; private set; }

        public IScholarShipApplicationRepository ScholarShipApplicationRepository { get; private set; }





        public UnitOfWork(AppWebDataContext context, IDbConnection dbConnection)
        {
            _context = context;
            _dbConnection = dbConnection;

            StudentRepository = new StudentRepository(_context);
            AdminRepository = new AdminRepository(_context);
            ScholarShipRepository = new ScholarShipRepository(_context);
            IndividualRepository = new IndividualRepository(_context);
            ScholarShipApplicationRepository= new ScholarShipApplicationRepository(_context);



        }





        public int SaveAllChanges()
        {
            try
            {
                return _context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void Dispose()
        {
            _context.Dispose();
        }


    }

}
