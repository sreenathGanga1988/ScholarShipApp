﻿using App.Domain.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace App.EfCore
{
    public partial class AppWebDataContext : DbContext
    {
       
        public AppWebDataContext()
        {
        }

        public AppWebDataContext(DbContextOptions<AppWebDataContext> options)
            : base(options)
        {

            //if (userService.GetStoreId() != null)
            //{
            //    storeid = int.Parse(userService.GetStoreId());
            //    DbUsername = userService.GetUser();
            //}

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
        }


        public virtual DbSet<Individual> Individuals { get; set; }


        public virtual DbSet<ScholarShip> ScholarShips { get; set; }

        public virtual DbSet<UserRole> UserRoles { get; set; }
        public virtual DbSet<ScholarShipApplication> ScholarShipApplication { get; set; }


      

        public override int SaveChanges()
        {
            try
            {
                var entries = ChangeTracker
                        .Entries()
                        .Where(e =>
                                e.State == EntityState.Added
                                || e.State == EntityState.Modified);

                foreach (var entityEntry in entries)
                {
                    entityEntry.Property("ModifiedDate").CurrentValue = Extensions.ClientTimeZone_DateNow(); ;

                    if (entityEntry.State == EntityState.Added)
                    {
                        entityEntry.Property("AddedDate").CurrentValue = DateTime.Now;
                    }
                }
            }
            catch (Exception)
            {
            }
            return base.SaveChanges();
        }

    }



  
}
