﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace App.EfCore.Migrations
{
    public partial class addedapplicationnew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_ScholarShipApplications_Individuals_IndividualID",
            //    table: "ScholarShipApplications");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_ScholarShipApplications_ScholarShips_ScholarShipID",
            //    table: "ScholarShipApplications");

            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_ScholarShipApplications",
            //    table: "ScholarShipApplications");

            //migrationBuilder.RenameTable(
            //    name: "ScholarShipApplications",
            //    newName: "ScholarShipApplication");

            //migrationBuilder.RenameIndex(
            //    name: "IX_ScholarShipApplications_ScholarShipID",
            //    table: "ScholarShipApplication",
            //    newName: "IX_ScholarShipApplication_ScholarShipID");

            //migrationBuilder.RenameIndex(
            //    name: "IX_ScholarShipApplications_IndividualID",
            //    table: "ScholarShipApplication",
            //    newName: "IX_ScholarShipApplication_IndividualID");

            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_ScholarShipApplication",
            //    table: "ScholarShipApplication",
            //    column: "ID");

            //migrationBuilder.AddForeignKey(
            //    name: "FK_ScholarShipApplication_Individuals_IndividualID",
            //    table: "ScholarShipApplication",
            //    column: "IndividualID",
            //    principalTable: "Individuals",
            //    principalColumn: "ID",
            //    onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_ScholarShipApplication_ScholarShips_ScholarShipID",
            //    table: "ScholarShipApplication",
            //    column: "ScholarShipID",
            //    principalTable: "ScholarShips",
            //    principalColumn: "ID",
            //    onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_ScholarShipApplication_Individuals_IndividualID",
            //    table: "ScholarShipApplication");

            //migrationBuilder.DropForeignKey(
            //    name: "FK_ScholarShipApplication_ScholarShips_ScholarShipID",
            //    table: "ScholarShipApplication");

            //migrationBuilder.DropPrimaryKey(
            //    name: "PK_ScholarShipApplication",
            //    table: "ScholarShipApplication");

            //migrationBuilder.RenameTable(
            //    name: "ScholarShipApplication",
            //    newName: "ScholarShipApplications");

            //migrationBuilder.RenameIndex(
            //    name: "IX_ScholarShipApplication_ScholarShipID",
            //    table: "ScholarShipApplications",
            //    newName: "IX_ScholarShipApplications_ScholarShipID");

            //migrationBuilder.RenameIndex(
            //    name: "IX_ScholarShipApplication_IndividualID",
            //    table: "ScholarShipApplications",
            //    newName: "IX_ScholarShipApplications_IndividualID");

            //migrationBuilder.AddPrimaryKey(
            //    name: "PK_ScholarShipApplications",
            //    table: "ScholarShipApplications",
            //    column: "ID");

            //migrationBuilder.AddForeignKey(
            //    name: "FK_ScholarShipApplications_Individuals_IndividualID",
            //    table: "ScholarShipApplications",
            //    column: "IndividualID",
            //    principalTable: "Individuals",
            //    principalColumn: "ID",
            //    onDelete: ReferentialAction.Cascade);

            //migrationBuilder.AddForeignKey(
            //    name: "FK_ScholarShipApplications_ScholarShips_ScholarShipID",
            //    table: "ScholarShipApplications",
            //    column: "ScholarShipID",
            //    principalTable: "ScholarShips",
            //    principalColumn: "ID",
            //    onDelete: ReferentialAction.Cascade);
        }
    }
}
