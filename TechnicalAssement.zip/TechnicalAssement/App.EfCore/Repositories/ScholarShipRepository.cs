﻿using App.Domain.Interfaces;
using App.Domain.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace App.EfCore.Repositories
{
    public class ScholarShipRepository : GenericRepository<ScholarShip>, IScholarShipRepository
    {
        public ScholarShipRepository(AppWebDataContext webDataContext) : base(context: webDataContext)
        {

        }
        public List<dynamic> GetSelectList(Expression<Func<ScholarShip, bool>> expression, int skip = 0, int nop = 0)
        {

            var k = _context.ScholarShips.Where(expression).AsQueryable();

            if (skip != 0)
            {
                k = k.Skip(skip);
            }
            if (nop != 0)
            {
                k = k.Take(nop);
            }
            var q = k.Select(u => new { code = u.ID.ToString(), label = u.Name.ToString() }).ToList<dynamic>();
            return q;
        }

        
    }

    public class ScholarShipApplicationRepository : GenericRepository<ScholarShipApplication>, IScholarShipApplicationRepository
    {
        public ScholarShipApplicationRepository(AppWebDataContext webDataContext) : base(context: webDataContext)
        {

        }
        


    }
}