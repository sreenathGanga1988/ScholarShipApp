﻿using App.Domain.Interfaces;
using App.Domain.Models;
using App.EfCore.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.EfCore.Repositories
{
    public class IndividualRepository : GenericRepository<Individual>, IIndividualRepository 
    {
        public IndividualRepository(AppWebDataContext dbcontext) : base(context: dbcontext)
        {

        }
      
    }
}
