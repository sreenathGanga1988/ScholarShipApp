﻿using App.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace App.EfCore.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        protected readonly AppWebDataContext _context;

        public String CurrentUser { get; set; }


        public GenericRepository(AppWebDataContext context)
        {
            _context = context;
        }

        public void Add(T entity)
        {
            _context.Set<T>().Add(entity);
        }

        public void AddRange(IEnumerable<T> entities)
        {
            _context.Set<T>().AddRange(entities);
        }

        public void Update(T entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
        }
        public void DisconnectedUpdate(T entity)
        {
            _context.Set<T>().Update(entity);
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> expression)
        {
            return _context.Set<T>().Where(expression);
        }

        public IEnumerable<T> GetAll()
        {
            try
            {
                var data = _context.Set<T>().ToList();
                return data;
            }
            catch (Exception ex)
            {
                string k = ex.Message;
                throw;

            }

        }

        public T GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }

        public void Remove(T entity)
        {
            _context.Set<T>().Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            _context.Set<T>().RemoveRange(entities);
        }

        public bool DataExists(Expression<Func<T, bool>> expression)
        {
            return _context.Set<T>().Any(expression);

        }
        public int DataCount(Expression<Func<T, bool>> expression)
        {
            int count = 0;
            try
            {
                count = _context.Set<T>().Where(expression).Count();
            }
            catch (Exception)
            {


            }

            return count;

        }
    }
}
