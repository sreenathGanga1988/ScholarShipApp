﻿

using App.Domain.Interfaces;
using App.Domain.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace App.EfCore.Repositories
{
    public class AdminRepository : GenericRepository<Individual>, IAdminRepository
    {
        public AdminRepository(AppWebDataContext webDataContext) : base(context: webDataContext)
        {

        }

        

    }
}