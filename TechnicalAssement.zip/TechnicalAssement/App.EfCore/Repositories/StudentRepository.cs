﻿

using App.Domain.Interfaces;
using App.Domain.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace App.EfCore.Repositories
{
    public class StudentRepository : GenericRepository<Individual>, IIndividualRepository
    {
        public StudentRepository(AppWebDataContext webDataContext) : base(context: webDataContext)
        {

        }



    }
}